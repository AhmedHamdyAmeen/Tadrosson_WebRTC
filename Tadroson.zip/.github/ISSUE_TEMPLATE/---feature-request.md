---
name: "\U0001F680 Feature request"
about: Suggest a new feature to improve Tadrosoon.
title: ''
labels: ''
assignees: ''

---

### Feature request

A clear and concise description of the feature request.

### Pros

A clear and concise description of the feature request pros.

### Additional context

Add any other context or screenshots about the feature request here.
